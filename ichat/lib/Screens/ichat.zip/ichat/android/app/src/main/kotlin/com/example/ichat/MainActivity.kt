package com.example.ichat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
